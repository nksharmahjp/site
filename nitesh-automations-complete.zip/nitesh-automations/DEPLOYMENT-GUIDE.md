# 📦 NITESH AUTOMATIONS — COMPLETE DEPLOYMENT GUIDE
## Step-by-Step Setup | सभी Steps हिंदी में

---

## 📋 TABLE OF CONTENTS
1. Google Sheets Database Setup
2. Google Apps Script (Telegram Bot) Deploy
3. Website Hosting (Netlify/GitHub Pages)
4. Telegram Bot Create & Connect
5. Razorpay Payment Integration
6. Google AdSense Setup
7. Angel One Referral Setup
8. Testing Checklist
9. Troubleshooting

---

# STEP 1: GOOGLE SHEETS DATABASE SETUP

## 1.1 — New Spreadsheet बनाएं

1. sheets.google.com पर जाएं
2. "+ New" click करें → "Blank spreadsheet"
3. Name दें: **"Nitesh Automations DB"**
4. URL से Sheet ID copy करें:
   - URL: `https://docs.google.com/spreadsheets/d/[SHEET_ID]/edit`
   - [SHEET_ID] को note करें

## 1.2 — Sheets Structure

Bot के `initializeSheets()` function से auto-create होगा। 
Manual बनाना हो तो:

### Sheet 1: "Users"
| UserID | Name | Mobile | TelegramChatID | Username | ReferralCode | ReferredBy | JoinDate | Status |

### Sheet 2: "Reports"
| ReportID | Name | Language | Price | FileURL | Sector | OriginalPrice | CreatedAt |

Sample data add करें:
| R001 | RELIANCE Industries Analysis | Hindi | 99 | [PDF URL] | Energy | 199 | |
| R002 | TCS Comprehensive Report | English | 149 | [PDF URL] | IT | 299 | |
| R003 | HDFC Bank Deep Dive | Hindi | 99 | [PDF URL] | Banking | 199 | |

### Sheet 3: "Payments"
| PaymentID | UserID | ReportID | Amount | Status | Date | TransactionRef |

### Sheet 4: "Referrals"
| ReferrerID | ReferredUserID | Earnings | Date | Status |

### Sheet 5: "Contact"
| Name | Contact | Subject | Message | Date |

## 1.3 — Sharing Permissions
1. Spreadsheet → Share button
2. "Anyone with link" → Viewer (for safety)
3. Apps Script को automatically access मिलेगा

---

# STEP 2: GOOGLE APPS SCRIPT — TELEGRAM BOT

## 2.1 — New Apps Script Project

1. script.google.com पर जाएं
2. "+ New project" click करें
3. Name दें: **"Nitesh Automations Bot"**

## 2.2 — Code Paste करें

1. `telegram-bot.gs` file का सारा code copy करें
2. Apps Script editor में paste करें
3. Default "Code.gs" को replace करें

## 2.3 — Configuration Update करें

File के top पर CONFIG object में update करें:

```javascript
const CONFIG = {
  BOT_TOKEN: "1234567890:ABCdef...",        // BotFather से मिला token
  SPREADSHEET_ID: "1BxiMVs0XRA5...",        // Sheets ID
  ADMIN_CHAT_ID: "123456789",               // आपका Telegram chat ID
  BOT_USERNAME: "@YourBotUsername",
  WEBSITE_URL: "https://yoursite.com",
  ANGEL_ONE_URL: "https://angel-one.onelink.me/Wjgr/YOUR_REF_CODE",
  UPI_ID: "yourname@upi",
  COMMISSION_RATE: 50,
  MIN_WITHDRAWAL: 200,
};
```

## 2.4 — Sheets Initialize करें

1. Function dropdown में `initializeSheets` select करें
2. ▶ Run button click करें
3. Permission grant करें (Allow)
4. Sheet में सभी columns automatically बन जाएंगे ✅

## 2.5 — Deploy as Web App

1. Deploy → New Deployment click करें
2. Type: **Web App** select करें
3. Settings:
   - Description: "Nitesh Automations Bot v1"
   - Execute as: **Me** (आपका account)
   - Who has access: **Anyone**
4. Deploy click करें
5. Web App URL copy करें (यह आपका webhook URL है)

## 2.6 — Webhook Connect करें

1. Function dropdown में `setWebhook` select करें
2. ▶ Run click करें
3. Logs में "Webhook set: {"ok":true}" दिखेगा ✅

---

# STEP 3: TELEGRAM BOT CREATE

## 3.1 — BotFather से Bot बनाएं

1. Telegram open करें
2. @BotFather search करें
3. `/newbot` command send करें
4. Bot name enter करें: **"Nitesh Automations"**
5. Username enter करें: **"NiteshAutomationsBot"** (unique होना चाहिए)
6. Token मिलेगा जैसे: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`
7. यह token CONFIG.BOT_TOKEN में paste करें

## 3.2 — Bot Commands Set करें

BotFather में `/setcommands` send करें:

```
start - Bot शुरू करें
menu - Main menu
reports - Research reports देखें
demat - Free Demat account
earnings - My earnings
referral - Referral info
support - Support contact
help - Help & commands
```

## 3.3 — Bot Description Set करें

```
/setdescription
```
Description:
```
📈 Nitesh Automations Bot

Stock Market Research Reports (Hindi & English)
Free Demat Account Opening
Referral Commission Earning

/start से शुरू करें!
```

## 3.4 — आपका Chat ID Find करें

1. @userinfobot को `/start` send करें
2. आपका chat ID मिलेगा
3. CONFIG.ADMIN_CHAT_ID में paste करें

---

# STEP 4: WEBSITE HOSTING

## Option A: Netlify (RECOMMENDED — FREE)

1. netlify.com पर account बनाएं
2. "Add new site" → "Deploy manually"
3. `index.html` file drag & drop करें
4. Site automatically deploy होगी
5. Custom domain add करें: Settings → Domain Management
   - Free domain: `yoursite.netlify.app`
   - Custom: `niteshautomations.com`

## Option B: GitHub Pages (FREE)

1. github.com पर account बनाएं
2. New Repository बनाएं: `nitesh-automations`
3. Repository को Public रखें
4. `index.html` upload करें
5. Settings → Pages → Source: `main` branch
6. URL: `https://yourusername.github.io/nitesh-automations`

## Option C: Blogger (GOOGLE — FREE)

1. blogger.com पर जाएं
2. New Blog बनाएं
3. Theme → Edit HTML
4. HTML code paste करें
5. Custom domain connect करें

## Option D: Hostinger / GoDaddy (PAID — ₹99/month)

1. Account बनाएं
2. Hosting plan खरीदें
3. File Manager में `index.html` upload करें
4. Domain connect करें

---

# STEP 5: RAZORPAY PAYMENT INTEGRATION

## 5.1 — Razorpay Account बनाएं

1. razorpay.com पर जाएं
2. Sign up करें (Free)
3. Business details fill करें
4. KYC complete करें (2-3 days)

## 5.2 — API Keys लें

1. Dashboard → Settings → API Keys
2. "Generate Key" click करें
3. Key ID और Secret copy करें:
   - Key ID: `rzp_live_XXXXXXXXXX`
   - Secret: `XXXXXXXXXXXXXXXXX`

## 5.3 — Website में Add करें

`index.html` में find करें:
```javascript
key: "YOUR_RAZORPAY_KEY",
```
Replace करें:
```javascript
key: "rzp_live_XXXXXXXXXX",
```

Razorpay script uncomment करें:
```html
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
```

## 5.4 — Payment Verification (Server-side)

Google Apps Script में payment verify करें:

```javascript
function verifyRazorpayPayment(orderId, paymentId, signature) {
  // Razorpay signature verification
  // अपने backend पर implement करें
  // या Razorpay dashboard में manually verify करें
}
```

## 5.5 — Test Mode

पहले test mode में try करें:
- Test Key: `rzp_test_XXXXXXXXXX`
- Test Card: 4111 1111 1111 1111
- Expiry: Any future date
- CVV: Any 3 digits

---

# STEP 6: GOOGLE ADSENSE SETUP

## 6.1 — AdSense Account

1. adsense.google.com पर जाएं
2. Get Started click करें
3. Website URL enter करें
4. Application submit करें (Approval 2-4 weeks)

## 6.2 — Auto Ads Enable करें

1. Approved होने पर Dashboard → Ads
2. Auto ads toggle ON करें
3. Code copy करें:

```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
     crossorigin="anonymous"></script>
```

## 6.3 — Website में Add करें

`index.html` में `<head>` के अंदर paste करें।

## 6.4 — Manual Ad Units

Website के ad placeholder sections में replace करें:

```html
<!-- Google AdSense Code Here -->
```

Replace with:
```html
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
```

---

# STEP 7: ANGEL ONE REFERRAL SETUP

## 7.1 — Referral Link Generate करें

1. Angel One में account खोलें: angelone.in
2. Refer & Earn section खोलें
3. आपका unique referral link copy करें
4. Format: `https://angel-one.onelink.me/Wjgr/YOURCODE`

## 7.2 — Website में Update करें

`index.html` में find करें:
```
https://angel-one.onelink.me/Wjgr/referral
```

Replace करें अपने actual referral link से।

## 7.3 — Bot में Update करें

`telegram-bot.gs` में:
```javascript
ANGEL_ONE_URL: "https://angel-one.onelink.me/Wjgr/YOURCODE",
```

---

# STEP 8: PDF REPORTS SETUP

## 8.1 — Google Drive में PDFs Upload करें

1. drive.google.com पर जाएं
2. New Folder: "Nitesh Automations Reports"
3. PDF files upload करें
4. Each file पर right click → Share
5. "Anyone with link" → Viewer
6. Link copy करें

## 8.2 — Google Sheets में Add करें

Reports sheet में FileURL column में paste करें।

## 8.3 — Direct Download Link

Google Drive link को direct download link में convert करें:

Original: `https://drive.google.com/file/d/FILE_ID/view`
Convert to: `https://drive.google.com/uc?export=download&id=FILE_ID`

---

# STEP 9: SEO OPTIMIZATION

## 9.1 — Meta Tags (already in index.html)

Update करें अपने actual info से:
```html
<meta name="description" content="Your actual description">
<meta property="og:title" content="Your title">
```

## 9.2 — Google Analytics

1. analytics.google.com पर account बनाएं
2. Property create करें
3. Tracking code copy करें
4. `<head>` में paste करें:

```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

## 9.3 — Sitemap

sitemap.xml बनाएं:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://niteshautomations.com/</loc><priority>1.0</priority></url>
  <url><loc>https://niteshautomations.com/#about</loc><priority>0.8</priority></url>
  <url><loc>https://niteshautomations.com/#reports</loc><priority>0.9</priority></url>
</urlset>
```

---

# STEP 10: TESTING CHECKLIST

## Website Testing
- [ ] Home page load हो रही है
- [ ] Navigation काम कर रही है
- [ ] Dark/Light mode toggle
- [ ] Reports page दिख रही है
- [ ] Payment modal open होता है
- [ ] Contact form submit होती है
- [ ] Mobile responsive है
- [ ] Angel One link काम करता है

## Telegram Bot Testing
- [ ] /start command काम करता है
- [ ] Main menu buttons काम करते हैं
- [ ] Reports list दिखती है
- [ ] Preview button काम करता है
- [ ] Payment flow complete होता है
- [ ] Referral link generate होता है
- [ ] Admin commands काम करते हैं
- [ ] Broadcast message जाता है

## Payment Testing
- [ ] Razorpay test payment succeeds
- [ ] UPI details सही दिखते हैं
- [ ] Payment confirmation message आता है
- [ ] PDF download link मिलता है

---

# TROUBLESHOOTING

## Bot Reply नहीं कर रहा
- Webhook सही set है? `setWebhook()` दोबारा run करें
- BOT_TOKEN सही है?
- Apps Script deploy सही से हुई?
- Logs check करें: Apps Script → Executions

## Sheet में Data नहीं जा रहा
- SPREADSHEET_ID सही है?
- Apps Script को Sheet access है?
- `initializeSheets()` run किया?

## Payment Fail हो रहा है
- Razorpay key सही है?
- Test mode vs Live mode check करें
- Console errors check करें (F12)

## Referral Track नहीं हो रहा
- Referrals sheet exist करती है?
- Referral code format: `NA-XXXXXX`
- processReferral() function call हो रही है?

---

# QUICK REFERENCE

## Important URLs
- Website: https://niteshautomations.com
- Bot: https://t.me/NiteshAutomationsBot
- Admin: https://niteshautomations.com → /admin
- Google Sheets: https://docs.google.com/spreadsheets/d/[SHEET_ID]
- Apps Script: https://script.google.com

## Support Contacts
- WhatsApp: +91 XXXXX XXXXX
- Email: nitesh@niteshautomations.com
- Telegram: @NiteshAutomations

## Revenue Streams
1. Report Sales: ₹49–₹299 per report
2. Angel One Referral: ₹500–₹2000 per demat account
3. Google AdSense: CPM based
4. Excel/Tally Services: ₹999–₹5000 per project
5. User Referrals: Platform growth

---

⚠️ LEGAL DISCLAIMER:
All content on this platform is for educational purposes only.
We are not SEBI-registered investment advisors.
Stock market investments are subject to market risks.
Past performance is not indicative of future results.

© 2024 Nitesh Automations. All rights reserved.
